# Deploy Guide — Saima Agar Attar & Dehn Al Oud

This folder is ready for **GitHub Pages** or **Netlify**.

## GitHub Pages (quick)
1) Create a new repo on GitHub (e.g., `saima-agar-website`).
2) Upload everything from the `site/` folder (or push via git).
3) Go to **Settings → Pages** → Build & deployment → Branch = `main`, Folder = `/ (root)` → **Save**.
4) Your site will be live at `https://<username>.github.io/<repo>/`.
   - If you have a custom domain, delete the `CNAME` file here and add your domain in Pages settings instead.

### Git via command line
```bash
git init
git add .
git commit -m "Initial site"
git branch -M main
git remote add origin https://github.com/<username>/saima-agar-website.git
git push -u origin main
```

## Netlify (drag & drop)
1) Go to https://app.netlify.com → **Add new site** → **Deploy manually**.
2) Drag the `site/` folder into Netlify. Done!
   - Or connect to Git: New site from Git → pick your repo. Build command: *(leave empty)*, Publish directory: `/`.

## Files included
- `index.html` — single page site
- `assets/logo.png` — logo (also used as favicon)
- `assets/attar.jpg`, `assets/agarwood.jpg` — product photos
- `netlify.toml` — sensible defaults for Netlify
- `CNAME` — optional for GitHub Pages custom domain (edit/remove as needed)

---

# WhatsApp Autofill (copy & use)
Replace the phone with **IE**: `0035385255945` or **BD**: `008801715409101`.

## Attar (10–12ml, ৳ 6,500)
IE:
https://wa.me/0035385255945?text=%E0%A6%86%E0%A6%B8%E0%A6%B8%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%AE%E0%A7%81%E0%A6%86%E0%A6%B2%E0%A7%9F%E0%A6%BF%E0%A6%95%E0%A7%81%E0%A6%AE%2C%20%E0%A6%86%E0%A6%AE%E0%A6%BF%20**Attar%20(10%E2%80%9312ml)**%20%E0%A6%A8%E0%A6%BF%E0%A6%A4%E0%A7%87%20%E0%A6%9A%E0%A6%BE%E0%A6%87.%20%E0%A6%A6%E0%A6%BE%E0%A6%AE%3A%20%E0%A6%B0%E0%A6%BE%E0%A6%93%20%E0%A7%AC%2C%E0%A7%AB%E0%A7%A6%E0%A7%A6.%20%E0%A6%B2%E0%A7%8B%E0%A6%95%E0%A7%87%E0%A6%B6%E0%A6%A8%3A%20SYLHET.

BD:
https://wa.me/008801715409101?text=%E0%A6%86%E0%A6%B8%E0%A6%B8%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%AE%E0%A7%81%E0%A6%86%E0%A6%B2%E0%A7%9F%E0%A6%BF%E0%A6%95%E0%A7%81%E0%A6%AE%2C%20%E0%A6%86%E0%A6%AE%E0%A6%BF%20**Attar%20(10%E2%80%9312ml)**%20%E0%A6%A8%E0%A6%BF%E0%A6%A4%E0%A7%87%20%E0%A6%9A%E0%A6%BE%E0%A6%87.%20%E0%A6%A6%E0%A6%BE%E0%A6%AE%3A%20%E0%A6%B0%E0%A6%BE%E0%A6%93%20%E0%A7%AC%2C%E0%A7%AB%E0%A7%A6%E0%A7%A6.%20%E0%A6%B2%E0%A7%8B%E0%A6%95%E0%A7%87%E0%A6%B6%E0%A6%A8%3A%20SYLHET.

## Agarwood (100g, ৳ 10,000–30,000)
IE:
https://wa.me/0035385255945?text=%E0%A6%86%E0%A6%97%E0%A6%BE%E0%A6%B0%E0%A6%89%E0%A6%A1%20(100g)%20%E0%A6%A8%E0%A6%BF%E0%A6%A4%E0%A7%87%20%E0%A6%9A%E0%A6%BE%E0%A6%87.%20%E0%A6%AC%E0%A6%BE%E0%A6%9C%E0%A7%87%E0%A6%9F%3A%20%E0%A7%A7%E0%A7%A6%E0%A7%A6%E0%A7%A6%E0%A7%A6%20%E2%80%93%203%E0%A7%A6%E0%A7%A6%E0%A7%A6%E0%A7%A6%20%E0%A6%9F%E0%A6%BE%E0%A6%95%E0%A6%BE.%20%E0%A6%B2%E0%A7%8B%E0%A6%95%E0%A7%87%E0%A6%B6%E0%A6%A8%3A%20SYLHET.

BD:
https://wa.me/008801715409101?text=%E0%A6%86%E0%A6%97%E0%A6%BE%E0%A6%B0%E0%A6%89%E0%A6%A1%20(100g)%20%E0%A6%A8%E0%A6%BF%E0%A6%A4%E0%A7%87%20%E0%A6%9A%E0%A6%BE%E0%A6%87.%20%E0%A6%AC%E0%A6%BE%E0%A6%9C%E0%A7%87%E0%A6%9F%3A%20%E0%A7%A7%E0%A7%A6%E0%A7%A6%E0%A7%A6%E0%A7%A6%20%E2%80%93%203%E0%A7%A6%E0%A7%A6%E0%A7%A6%E0%A7%A6%20%E0%A6%9F%E0%A6%BE%E0%A6%95%E0%A6%BE.%20%E0%A6%B2%E0%A7%8B%E0%A6%95%E0%A7%87%E0%A6%B6%E0%A6%A8%3A%20SYLHET.

---

Tip: You can also embed these links into the existing buttons in `index.html` if you ever change copy.
